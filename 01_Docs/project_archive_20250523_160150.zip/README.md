﻿# 01_Docs

This folder contains design documents, blueprints, and traceability records for the project.

- All modules must have a BLOCK ID and standard header.
- Simulation/test hooks are required in each logic module.
- See /02_Source/mod_001.py for an example.
